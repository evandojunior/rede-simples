<?php if(!isset($_SESSION)){ session_start(); } 
header('Location: corporativo/servicos/bi/index.php');
?>